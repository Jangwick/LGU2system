<?php
/**
 * Local Configuration
 * 
 * This file is EXCLUDED from version control (git).
 * Put your sensitive credentials and local environment settings here.
 */

// Gemini API Key
define('GEMINI_API_KEY', 'AIzaSyDCNzaTbNrfnToYROdJuDWYnITAag9uioM');

// Add other local overrides here if needed (e.g., local database password)
// define('DB_PASS', '');
// SMTP Configuration overrides
define('SMTP_USER', 'rickdummiest@gmail.com');
define('SMTP_PASS', 'jizv poxl lgnn sndj');
define('SMTP_FROM', 'rickdummiest@gmail.com');
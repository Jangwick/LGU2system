<?php
require_once __DIR__ . '/../../core/config/database.php';
require_once __DIR__ . '/../../core/utils/Logger.php';
require_once __DIR__ . '/../../notifications/models/Notification.php';

class IntegrationController {
    private $db;
    private $logger;
    private $notification;

    public function __construct() {
        $this->db = getDatabase();
        $this->logger = new Logger($this->db);
        $this->notification = new Notification();
    }

    /**
     * Get integrated records by module type
     */
    public function getRecords($type = null) {
        $sql = "SELECT * FROM integrated_records";
        $params = [];
        
        if ($type) {
            $sql .= " WHERE module_type = :type";
            $params[':type'] = $type;
        }
        
        $sql .= " ORDER BY received_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Receive data from external system
     */
    public function receive($data, $fileData = null) {
        $moduleType = $data['module_type'] ?? $data['type'] ?? null;
        $title = $data['title'] ?? null;

        if (empty($moduleType) || empty($title)) {
            return ['success' => false, 'error' => 'Missing required fields (module_type/type, title)'];
        }

        // Include file info in payload if uploaded
        $payload = $data['payload'] ?? [];
        if ($fileData) {
            $payload['file_path'] = $fileData['file_path'];
            $payload['file_name'] = $fileData['file_name'];
            $payload['file_size'] = $fileData['file_size'];
            $payload['file_type'] = $fileData['file_type'];
        }

        $stmt = $this->db->prepare("
            INSERT INTO integrated_records (module_type, external_id, title, summary, data_payload, source_system, status)
            VALUES (:type, :ext_id, :title, :summary, :payload, :source, 'pending')
        ");

        $result = $stmt->execute([
            ':type' => $moduleType,
            ':ext_id' => $data['external_id'] ?? null,
            ':title' => $title,
            ':summary' => $data['summary'] ?? null,
            ':payload' => json_encode($payload),
            ':source' => $data['source_system'] ?? 'External Integration'
        ]);

        if ($result) {
            $id = $this->db->lastInsertId();
            $this->logger->logActivity('INTEGRATION_RECEIVED', 'integrated_records', $id, "Received {$moduleType} from " . ($data['source_system'] ?? 'External Integration'));
            
            // Notify staff about incoming external data
            $this->notification->broadcast([
                'type' => 'integration',
                'title' => 'Incoming External Data',
                'message' => "New " . ($moduleType ?: 'record') . " received: " . $title,
                'source_module' => 'integration',
                'source_id' => $id,
                'data' => ['link' => "modules/integration/views/{$moduleType}.php"]
            ]);

            return ['success' => true, 'id' => $id];
        }

        return ['success' => false, 'error' => 'Failed to save record'];
    }

    /**
     * Import an integrated record into the main LRMS Document system
     */
    public function importToLRMS($id) {
        $stmt = $this->db->prepare("SELECT * FROM integrated_records WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$record) {
            return ['success' => false, 'error' => 'Record not found'];
        }

        if ($record['status'] === 'synced') {
            return ['success' => false, 'error' => 'Record already synced to LRMS'];
        }

        // Parse extra payload data
        $payload = json_decode($record['data_payload'], true) ?: [];
        $docDate = $payload['document_date'] ?? date('Y-m-d');
        $tags = $payload['tags'] ?? '';
        
        // Get file info from payload (uploaded during receive)
        $filePath = $payload['file_path'] ?? 'external_sync';
        $fileName = $payload['file_name'] ?? 'Synced Data';
        $fileSize = $payload['file_size'] ?? 0;
        $fileType = $payload['file_type'] ?? 'application/json';

        // Map module_type to document_type labels used in LRMS (Matches ENUM in documents table)
        $typeMap = [
            'ordinances' => 'ordinance',
            'sessions' => 'session',
            'agendas' => 'agenda',
            'committees' => 'committee',
            'research' => 'research',
            'resolutions' => 'resolution',
            'voting' => 'voting',
            'hearings' => 'hearing',
            'archives' => 'archive',
            'consultations' => 'consultation'
        ];
        $docType = $typeMap[$record['module_type']] ?? 'ordinance'; // Default to ordinance if unknown to satisfy ENUM

        // Generate a reference number
        $refPrefix = strtoupper(substr($docType, 0, 3));
        $refNum = $refPrefix . '-' . date('Y') . '-' . str_pad($id, 4, '0', STR_PAD_LEFT);

        // Insert into legislative_documents
        $stmt = $this->db->prepare("
            INSERT INTO legislative_documents (
                reference_number, title, document_type, document_date,
                status, description, tags, source_module, source_id,
                uploaded_by, created_at, file_path, file_name, file_size, file_type
            ) VALUES (
                :ref, :title, :type, :doc_date,
                'draft', :desc, :tags, 'integration', :source_id,
                :user_id, NOW(), :file_path, :file_name, :file_size, :file_type
            )
        ");

        $result = $stmt->execute([
            ':ref' => $refNum,
            ':title' => $record['title'],
            ':type' => $docType,
            ':doc_date' => $docDate,
            ':desc' => $record['summary'],
            ':tags' => $tags,
            ':source_id' => $id,
            ':user_id' => $_SESSION['user_id'] ?? 1,
            ':file_path' => $filePath,
            ':file_name' => $fileName,
            ':file_size' => $fileSize,
            ':file_type' => $fileType
        ]);

        if ($result) {
            $docId = $this->db->lastInsertId();
            
            // Update the integration record status
            $this->updateStatus($id, 'synced');
            
            $this->logger->logActivity('INTEGRATION_IMPORTED', 'legislative_documents', $docId, "Imported {$record['module_type']} Record #{$id} as Document #{$docId}");
            
            // Notify about successful sync
            $this->notification->broadcast([
                'type' => 'file',
                'title' => 'Record Imported',
                'message' => "External record '{$record['title']}' has been successfully imported as Document #$refNum",
                'source_module' => 'document-management',
                'source_id' => $docId,
                'data' => ['link' => "modules/document-management/views/view.php?id={$docId}"]
            ]);

            return ['success' => true, 'document_id' => $docId];
        }

        return ['success' => false, 'error' => 'Failed to create document'];
    }

    /**
     * Update status of a record
     */
    public function updateStatus($id, $status) {
        $stmt = $this->db->prepare("UPDATE integrated_records SET status = :status, processed_at = NOW() WHERE id = :id");
        return $stmt->execute([':status' => $status, ':id' => $id]);
    }
}

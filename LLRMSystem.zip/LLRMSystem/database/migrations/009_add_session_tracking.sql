-- Add last_session_id to users to prevent concurrent logins
ALTER TABLE users ADD COLUMN last_session_id VARCHAR(255) NULL AFTER status;

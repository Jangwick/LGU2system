-- Add employee_id column to users table
ALTER TABLE `users` ADD COLUMN `employee_id` VARCHAR(50) AFTER `id`;
ALTER TABLE `users` ADD UNIQUE KEY `unique_employee_id` (`employee_id`);

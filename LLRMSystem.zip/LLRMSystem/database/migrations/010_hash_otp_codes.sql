-- Migration 010: Widen otp_code column to store bcrypt hashes
-- OTPs are now stored as password_hash() bcrypt strings instead of plaintext 6-digit codes.
-- bcrypt output is 60 characters; VARCHAR(255) provides headroom for future algorithm changes.
-- The index on otp_code is dropped because hashes cannot be used for direct SQL equality lookups.

ALTER TABLE `user_otps`
    DROP INDEX `otp_code`,
    MODIFY COLUMN `otp_code` VARCHAR(255) NOT NULL COMMENT 'bcrypt hash of the OTP code';

-- Invalidate all existing plaintext OTP rows so they cannot be verified against hashes.
UPDATE `user_otps` SET `is_used` = 1 WHERE `is_used` = 0;

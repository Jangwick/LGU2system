-- Persistent API rate-limiting log.
-- Each row records a single API request.  checkRateLimit() counts rows within
-- the last 60 seconds per api_key_id; if the count reaches the limit the
-- request is rejected with HTTP 429.
-- Rows older than 5 minutes are pruned automatically by the middleware on
-- every rate-limit check to prevent unbounded table growth.

CREATE TABLE IF NOT EXISTS api_request_log (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    api_key_id  INT            NOT NULL,
    requested_at DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- Quick lookup: count requests in the rolling window for a given key
    INDEX idx_api_key_window (api_key_id, requested_at),
    -- Speed up the periodic cleanup query
    INDEX idx_requested_at   (requested_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
